const $ = id => document.getElementById(id);

let data = JSON.parse(localStorage.getItem("asharMarketingData") || '{"campaigns":[],"contents":0,"seo":0,"activity":[]}');

function saveData() {
  localStorage.setItem("asharMarketingData", JSON.stringify(data));
  updateDashboard();
}

function toast(message) {
  const el = $("toast");
  el.textContent = message;
  el.classList.add("show");
  setTimeout(() => el.classList.remove("show"), 2500);
}

function logActivity(message) {
  data.activity.unshift({ message, date: new Date().toLocaleString() });
  data.activity = data.activity.slice(0, 20);
  saveData();
}

function showPage(page) {
  document.querySelectorAll(".page").forEach(p => p.classList.remove("active-page"));
  document.querySelectorAll(".nav").forEach(n => n.classList.remove("active"));

  $(page).classList.add("active-page");
  const nav = document.querySelector(`[data-page="${page}"]`);
  if (nav) nav.classList.add("active");

  const titles = {
    dashboard: "Dashboard",
    content: "AI Content Studio",
    hashtags: "Hashtag Generator",
    seo: "SEO Tools",
    campaigns: "Campaign Planner",
    analytics: "Analytics"
  };

  $("pageTitle").textContent = titles[page];
  updateDashboard();
  window.scrollTo(0, 0);
}

document.querySelectorAll("[data-page]").forEach(btn => {
  btn.addEventListener("click", () => showPage(btn.dataset.page));
});

document.querySelectorAll("[data-go]").forEach(btn => {
  btn.addEventListener("click", () => showPage(btn.dataset.go));
});

// CONTENT GENERATOR
$("generateContent").addEventListener("click", () => {
  const product = $("product").value.trim();
  const platform = $("platform").value;
  const type = $("contentType").value;
  const offer = $("offer").value.trim();

  if (!product) {
    toast("Please enter your business or product name.");
    return;
  }

  const templates = {
    "Promotional Caption":
      `✨ Discover something amazing with ${product}!\n\nQuality, style and value come together. Explore our latest collection and experience the difference.\n\n${offer}\n\n📩 Contact us today for more details!`,

    "Product Launch":
      `🚀 Something NEW is here!\n\nIntroducing ${product} — created to bring you something special.\n\n${offer}\n\nStay tuned and be among the first to explore it!`,

    "Business Introduction":
      `Welcome to ${product}! 💙\n\nWe are passionate about delivering quality and creating a great experience for our customers.\n\n${offer}\n\nFollow us for updates, offers and more!`,

    "Engagement Post":
      `💬 Let's talk!\n\nWhat do you love most about ${product}?\n\nShare your thoughts in the comments below. We would love to hear from you!\n\n${offer}`,

    "Sale Announcement":
      `🔥 SPECIAL OFFER ALERT!\n\nIt's time to explore ${product} at an amazing value!\n\n${offer}\n\nDon't miss out. Contact us today!`
  };

  const caption = `${templates[type]}\n\n#${product.replace(/[^a-zA-Z0-9]/g, "")} #${platform.replace(/\s/g, "")} #Business #Marketing`;

  $("captionOutput").textContent = caption;
  $("contentResult").classList.remove("hidden");

  data.contents++;
  logActivity(`Created ${type} for ${product} (${platform})`);
  toast("Content generated successfully!");
});

// HASHTAG GENERATOR
$("generateTags").addEventListener("click", () => {
  const niche = $("niche").value.trim();

  if (!niche) {
    toast("Please enter a topic.");
    return;
  }

  const clean = niche.replace(/[^a-zA-Z0-9]/g, "");
  const words = niche.toLowerCase().split(/\s+/).filter(Boolean);
  const base = words.map(w => w.replace(/[^a-z0-9]/g, "")).join("");

  const tags = [
    "#" + clean,
    "#" + base + "Tips",
    "#" + base + "Ideas",
    "#" + base + "Business",
    "#DigitalMarketing",
    "#MarketingStrategy",
    "#SmallBusiness",
    "#BusinessGrowth",
    "#SocialMediaMarketing",
    "#ContentCreation",
    "#Entrepreneurship",
    "#BrandBuilding",
    "#OnlineBusiness",
    "#ExploreMore",
    "#Trending"
  ];

  const uniqueTags = [...new Set(tags)];

  $("tagOutput").textContent = uniqueTags.join(" ");
  $("tagResult").classList.remove("hidden");

  logActivity(`Generated hashtags for ${niche}`);
  toast("Hashtags generated!");
});

// SEO CHECKER
$("runSEO").addEventListener("click", () => {
  const url = $("seoUrl").value.trim();
  const title = $("seoTitle").value.trim();
  const description = $("seoDescription").value.trim();
  const keyword = $("seoKeyword").value.trim();

  if (!url || !title || !description || !keyword) {
    toast("Please complete all SEO fields.");
    return;
  }

  const checks = [
    {
      name: "Website URL",
      ok: /^https?:\/\/.+\..+/.test(url),
      advice: "Use a valid URL starting with https://"
    },
    {
      name: "Page Title",
      ok: title.length >= 30 && title.length <= 60,
      advice: "Aim for a title around 30–60 characters."
    },
    {
      name: "Meta Description",
      ok: description.length >= 120 && description.length <= 160,
      advice: "Aim for a description around 120–160 characters."
    },
    {
      name: "Main Keyword",
      ok: title.toLowerCase().includes(keyword.toLowerCase()),
      advice: "Consider including your main keyword in the title."
    },
    {
      name: "Description Keyword",
      ok: description.toLowerCase().includes(keyword.toLowerCase()),
      advice: "Consider including your keyword in the description."
    }
  ];

  const score = checks.filter(c => c.ok).length;
  const percent = Math.round(score / checks.length * 100);

  $("seoResult").innerHTML = `
    <div class="result-head">
      <b>SEO Checklist Results</b>
      <strong style="color:#55adff">${percent}%</strong>
    </div>
    <div style="font-size:25px;margin-bottom:15px">${score}/5 checks passed</div>
    ${checks.map(c => `
      <div style="padding:10px 0;border-bottom:1px solid #233047">
        <strong style="color:${c.ok ? '#55d6a0' : '#ffae70'}">
          ${c.ok ? '✓' : '○'} ${c.name}
        </strong>
        <div style="color:#8794aa;font-size:11px;margin-top:5px">
          ${c.ok ? 'Basic check passed' : c.advice}
        </div>
      </div>
    `).join("")}
    <p style="color:#8794aa;font-size:10px;margin-top:15px">
      This is a basic input-based SEO checklist, not a live website crawl or Google ranking report.
    </p>
  `;

  $("seoResult").classList.remove("hidden");

  data.seo++;
  logActivity(`Completed SEO checklist for ${url}`);
  toast("SEO check completed!");
});

// CAMPAIGN PLANNER
$("saveCampaign").addEventListener("click", () => {
  const name = $("campaignName").value.trim();
  const platform = $("campaignPlatform").value;
  const budget = Number($("campaignBudget").value);
  const date = $("campaignDate").value;

  if (!name || !date || $("campaignBudget").value === "" || !Number.isFinite(budget) || budget < 0) {
    toast("Enter a campaign name, valid budget and date.");
    return;
  }

  data.campaigns.unshift({
    name,
    platform,
    budget,
    date,
    id: Date.now()
  });

  $("campaignName").value = "";
  $("campaignBudget").value = "";
  $("campaignDate").value = "";

  logActivity(`Saved campaign: ${name}`);
  renderCampaigns();
  toast("Campaign saved successfully!");
});

function renderCampaigns() {
  const list = $("campaignList");

  if (!data.campaigns.length) {
    list.innerHTML = '<p class="muted">No campaigns yet.</p>';
    return;
  }

  list.innerHTML = data.campaigns.map(c => `
    <div class="campaign-item">
      <div>
        <strong>${escapeHTML(c.name)}</strong>
        <small>${escapeHTML(c.platform)} · ${escapeHTML(c.date)}</small>
        <small>Budget: PKR ${Number(c.budget).toLocaleString()}</small>
      </div>
      <button class="copy" data-delete="${c.id}">Delete</button>
    </div>
  `).join("");

  list.querySelectorAll("[data-delete]").forEach(btn => {
    btn.addEventListener("click", () => {
      data.campaigns = data.campaigns.filter(c => c.id !== Number(btn.dataset.delete));
      saveData();
      renderCampaigns();
      toast("Campaign deleted.");
    });
  });
}

function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, char => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;"
  })[char]);
}

// COPY BUTTONS
document.addEventListener("click", async e => {
  const btn = e.target.closest("[data-copy]");
  if (!btn) return;

  const target = $(btn.dataset.copy);
  if (!target) return;

  try {
    await navigator.clipboard.writeText(target.innerText);
    toast("Copied to clipboard!");
  } catch {
    toast("Please select and copy the text manually.");
  }
});

// DASHBOARD & ANALYTICS
function updateDashboard() {
  $("campaignCount").textContent = data.campaigns.length;
  $("contentCount").textContent = data.contents;
  $("seoCount").textContent = data.seo;

  $("analyticsContent").textContent = data.contents;
  $("analyticsCampaigns").textContent = data.campaigns.length;
  $("analyticsSEO").textContent = data.seo;

  const activityHTML = data.activity.length
    ? data.activity.map(a => `
      <div class="activity-item">
        <span>${escapeHTML(a.message)}</span>
        <small style="color:#8794aa">${escapeHTML(a.date)}</small>
      </div>
    `).join("")
    : '<p class="muted">Your activities will appear here.</p>';

  $("activity").innerHTML = activityHTML;
  $("analyticsActivity").innerHTML = activityHTML;

  renderCampaigns();
}

updateDashboard();